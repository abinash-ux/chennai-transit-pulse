# Simulation configuration and scenario methodology

## 1. Purpose and separation from the prototype

This package documents the synthetic simulation scenario used for the quantitative evaluation. The dataset is used only for the simulation results. It is not real-world transit data and was not used as the operational data of the Chennai Transit Pulse prototype. The prototype demonstrates application workflows; the synthetic dataset supports the controlled simulation evaluation.

## 2. Fleet, routes, and observation design

The simulation dataset contains 14 bus identifiers across five route identifiers (R1–R5). Each bus has a nominal capacity of 70 passengers. The prototype's DBR logic documents this capacity as 40 seated plus 30 standing passengers.

The simulation horizon is 06:00–22:00. Occupancy is observed every two hours at 06:00, 08:00, 10:00, 12:00, 14:00, 16:00, 18:00, and 20:00. The horizon end (22:00) is not an additional observation. Each replication contains 14 × 8 = 112 bus-time observations; 30 replications yield 3,360 observations.

The simulation input identifies routes but does not contain stop-level passenger observations. Although the prototype route records contain start-stop, end-stop, and stops fields, no stop count or stop-level passenger movement is inferred for this simulation.

## 3. Occupancy input and replications

The released occupancy table is a fixed synthetic scenario input. It contains 30 replication identifiers and associated seed labels (7001–7030). These seed values identify the replications in the released dataset; the current reproduction script does not regenerate the original passenger counts from the seeds. Instead, it reads the fixed occupancy input and reproduces the derived DBR events, KPI tables, summary statistics, and threshold-sensitivity outputs.

Accordingly, this release is a reproducible analysis package for a fixed synthetic scenario, not a stochastic passenger-demand generator. No real-world passenger counts, GPS traces, or operational fleet records are represented.

## 4. DBR event scenario

The prototype DBR rule uses a 98% occupancy threshold and a route-level condition: at least three buses on the same route must have load factor greater than or equal to 98% at an observation time. A resulting reallocation is subject to administrator approval; the prototype does not automatically reassign a bus.

The simulation includes a controlled synthetic stress scenario on route R1 at 18:00 involving three buses at the DBR trigger condition. This scenario is included to exercise the route-level trigger and threshold-sensitivity analysis. It is not a field observation. The event table records admin-approved reallocation events, while passenger occupancy inputs remain unchanged after the event.

## 5. KPIs and sensitivity analysis

The three reported KPIs are:
- Load factor = passenger count / bus capacity, expressed as a percentage.
- Overcrowded observation share = number of bus-time observations at or above the selected threshold divided by all bus-time observations in the replication.
- Approved reallocations = number of admin-approved DBR event records per replication.

The operational DBR threshold is 98%. Sensitivity analysis additionally evaluates 90% and 95% as alternative experimental thresholds. Means and sample standard deviations (ddof=1) are calculated across 30 replications.

## 6. Scope and limitations

Baseline and proposed passenger inputs are identical, so the experiment does not demonstrate a reduction in load factor or overcrowded observations after DBR. The model records trigger and approval events but does not simulate passenger redistribution, added-capacity effects, or post-reallocation occupancy. Waiting time, reallocation cost, complaint-resolution duration, and SOS latency are not quantitatively measured.

A college dispersal example may be discussed as an illustrative operational scenario only; it is not a measured simulation outcome. Simulation findings must not be presented as real-world performance of the prototype.
