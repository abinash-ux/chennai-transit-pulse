# Chennai Transit Pulse — Reviewer 3 Comments 4 & 5 Reproducibility Package

## Purpose
This release combines the synthetic quantitative evaluation materials for Reviewer 3 Comment 4 with the simulation configuration, methodology, scenarios, and reproduction script for Comment 5. It contains no real-world passenger data.

## Package structure
- `comment4-results/` — reported Comment 4 datasets, replication-level KPI results, mean/SD summary, threshold-sensitivity tables, validation checks, data dictionary, and audit report.
- `input/synthetic_occupancy_scenario.csv` — fixed synthetic occupancy input consumed by the reproduction script.
- `scenarios/` — controlled stress-test scenario and synthetic DBR event records.
- `simulation_config.json` — machine-readable simulation configuration.
- `SIMULATION_METHODOLOGY.md` — methodology, experiment design, and limitations.
- `reproduce_simulation_results.py` and `requirements.txt` — script and dependencies to reproduce derived event/KPI/sensitivity outputs.
- `README_and_Data_Dictionary.json` — machine-readable data dictionary for the Comment 5 package.
- `AUDIT_REPORT.json` — audit report accompanying the Comment 5 configuration package.
- `LICENSE-DATA-CC-BY-4.0.txt`, `LICENSE-CODE-MIT.txt`, `README_LICENSE_SCOPE.md` — license notices and scope.

## Experiment at a glance
- 30 replications, identified by seed labels 7001–7030
- 14 buses and five synthetic route IDs (R1–R5)
- Nominal bus capacity: 70 passengers
- Simulation horizon: 06:00–22:00; observations every two hours from 06:00 through 20:00 (eight observation times)
- 112 bus-time observations per replication; 3,360 rows
- Operational DBR threshold: 98%; route-level trigger requires at least three buses on the same route at or above the threshold; admin approval is required
- Sensitivity thresholds: 90%, 95%, and 98%

## Reproduce the derived outputs
Use Python 3.9+ and the packages in `requirements.txt`.

```bash
pip install -r requirements.txt
python reproduce_simulation_results.py
```

Run from this package root. The script reads `input/synthetic_occupancy_scenario.csv` and writes derived outputs to `output/`.

## Reproducibility boundary
The occupancy input is a **fixed synthetic scenario**. The seed values label the 30 replications; the included script does not use them to regenerate passenger counts. The script recalculates DBR event, KPI, summary, sensitivity, and validation outputs from the fixed input. This package is a reproducible fixed-scenario analysis, **not** a stochastic passenger-demand or incident generator. No undocumented random-generation rules are claimed.

## Scenario and limitations
The controlled stress-test slice is route R1 at 18:00, with three buses per replication. It is synthetic, not a field observation. The simulation data contains route IDs but no stop-level passenger observations, so no stop count or stop-by-stop passenger movement is asserted. Baseline and proposed passenger-count inputs are identical; the evaluation records DBR trigger/approved reallocation events but does not simulate passenger redistribution or post-reallocation occupancy changes. Accordingly, it does not demonstrate a reduction in load factor or overcrowding. Waiting time, reallocation cost, complaint-resolution duration, and SOS latency are not measured.

The synthetic dataset is used only for this simulation evaluation. It is not real-world transit data and was not used as operational data for the Chennai Transit Pulse prototype.

## License scope
- **CC BY 4.0** applies to the synthetic datasets, scenario CSVs, simulation configuration, methodology, README/data dictionary, audit and validation reports, and other documentation/data files in this reproducibility package, except the Python reproduction script.
- **MIT** applies only to `reproduce_simulation_results.py`.
- Neither license applies to the existing Chennai Transit Pulse application/source code, dependencies, third-party assets, or any other files outside this explicitly scoped reproducibility package.

See `README_LICENSE_SCOPE.md` and the corresponding license files. Full CC BY 4.0 legal code: https://creativecommons.org/licenses/by/4.0/legalcode

## Citation and reuse
When reusing CC BY 4.0 materials, provide appropriate attribution to Chennai Transit Pulse project, link to CC BY 4.0, and indicate whether changes were made. Confirm that the project has authority to license all included materials before public release.
