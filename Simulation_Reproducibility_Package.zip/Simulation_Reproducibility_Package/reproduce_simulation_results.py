#!/usr/bin/env python3
"""Reproduce the reported DBR simulation event, KPI and sensitivity tables.

This script uses the released synthetic occupancy scenario as a fixed input.
It does NOT claim to regenerate passenger counts from random seeds. The
occupancy scenario itself is supplied in input/synthetic_occupancy_scenario.csv.
All downstream event and statistical tables are recalculated from that input.

Run from this directory:
    python reproduce_simulation_results.py
Requires: Python 3.9+ and pandas, numpy.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "input" / "synthetic_occupancy_scenario.csv"
OUTPUT = ROOT / "output"
OUTPUT.mkdir(exist_ok=True)
THRESHOLDS = (0.90, 0.95, 0.98)
OPERATIONAL_THRESHOLD = 0.98
MIN_BUSES_FOR_ROUTE_TRIGGER = 3
EXPECTED_REPLICATIONS = 30
EXPECTED_BUSES = 14
EXPECTED_OBSERVATIONS = 8

fleet = pd.read_csv(INPUT)
required = {
    "replication_id", "seed", "observation_time", "bus_id", "route_id",
    "passenger_count", "bus_capacity", "load_factor",
    "baseline_passenger_count", "proposed_passenger_count"
}
missing = required - set(fleet.columns)
if missing:
    raise ValueError(f"Input is missing required columns: {sorted(missing)}")

# Validate the frozen synthetic scenario input before deriving any outputs.
checks = []
def check(name, passed, detail):
    checks.append({"check": name, "passed": bool(passed), "detail": str(detail)})

check("30 replications", fleet.replication_id.nunique() == EXPECTED_REPLICATIONS,
      fleet.replication_id.nunique())
check("Seeds 7001-7030", sorted(fleet.seed.unique().tolist()) == list(range(7001,7031)),
      sorted(fleet.seed.unique().tolist()))
counts = fleet.groupby(["replication_id", "observation_time"]).bus_id.nunique()
check("14 buses per replication/time", bool((counts == EXPECTED_BUSES).all()),
      f"{len(counts)} replication-time snapshots")
check("8 observation times", fleet.observation_time.nunique() == EXPECTED_OBSERVATIONS,
      sorted(fleet.observation_time.unique().tolist()))
check("5 routes", fleet.route_id.nunique() == 5, fleet.route_id.nunique())
check("Capacity fixed at 70", bool((fleet.bus_capacity == 70).all()),
      sorted(fleet.bus_capacity.unique().tolist()))
check("Passenger counts within capacity",
      bool(((fleet.passenger_count >= 0) & (fleet.passenger_count <= fleet.bus_capacity)).all()),
      f"min={fleet.passenger_count.min()}, max={fleet.passenger_count.max()}")
check("Load factor formula", bool(np.allclose(fleet.load_factor,
      fleet.passenger_count / fleet.bus_capacity)), "load_factor = passenger_count / bus_capacity")
check("Baseline/proposed passenger inputs paired",
      bool(((fleet.baseline_passenger_count == fleet.passenger_count) &
            (fleet.proposed_passenger_count == fleet.passenger_count)).all()),
      "All scenario passenger counts are unchanged between methods")
check("Unique bus-time keys", not fleet.duplicated(
      ["replication_id", "observation_time", "bus_id"]).any(), "No duplicate bus-time records")
if not all(x["passed"] for x in checks):
    pd.DataFrame(checks).to_csv(OUTPUT/"07_Validation_Checks.csv", index=False)
    raise ValueError("Scenario input validation failed; see output/07_Validation_Checks.csv")

# Route-level event log: at least three buses on a route at >=98% at an
# observation time. This is a synthetic decision event, not a passenger-flow
# or occupancy-reduction model. Event records represent admin approval.
events=[]
for (rid, seed, time, route), group in fleet.groupby(
        ["replication_id", "seed", "observation_time", "route_id"], sort=True):
    n_over = int((group.load_factor >= OPERATIONAL_THRESHOLD).sum())
    if n_over >= MIN_BUSES_FOR_ROUTE_TRIGGER:
        events.append({
            "replication_id": int(rid), "seed": int(seed),
            "observation_time": time, "route_id": route,
            "trigger_threshold": OPERATIONAL_THRESHOLD,
            "overcrowded_buses_on_route": n_over,
            "reallocation_count": 1, "approval_status": "approved",
            "reassignment_automatic": False,
            "note": "Admin-approved DBR event; passenger occupancy inputs unchanged"
        })
events_df = pd.DataFrame(events, columns=[
    "replication_id", "seed", "observation_time", "route_id", "trigger_threshold",
    "overcrowded_buses_on_route", "reallocation_count", "approval_status",
    "reassignment_automatic", "note"])

# Replication-level KPIs.
rep_rows=[]
for (rid, seed), group in fleet.groupby(["replication_id", "seed"], sort=True):
    mean_load = group.load_factor.mean() * 100
    over_share = (group.load_factor >= OPERATIONAL_THRESHOLD).mean() * 100
    n_events = int((events_df.replication_id == rid).sum()) if not events_df.empty else 0
    rep_rows.append({
        "replication_id": int(rid), "seed": int(seed),
        "baseline_mean_load_factor_pct": mean_load,
        "proposed_mean_load_factor_pct": mean_load,
        "baseline_overcrowded_observation_share_pct": over_share,
        "proposed_overcrowded_observation_share_pct": over_share,
        "baseline_reallocations": 0,
        "proposed_approved_reallocations": n_events
    })
rep_df=pd.DataFrame(rep_rows)

# Mean and sample SD across replication-level values (ddof=1).
summary_specs = [
    ("Baseline mean load factor (%)", "baseline_mean_load_factor_pct"),
    ("Proposed mean load factor (%)", "proposed_mean_load_factor_pct"),
    ("Baseline overcrowded observation share (%)", "baseline_overcrowded_observation_share_pct"),
    ("Proposed overcrowded observation share (%)", "proposed_overcrowded_observation_share_pct"),
    ("Baseline reallocations per replication", "baseline_reallocations"),
    ("Proposed approved reallocations per replication", "proposed_approved_reallocations")
]
summary=[]
for label, col in summary_specs:
    summary.append({"metric": label, "mean": rep_df[col].mean(),
                    "standard_deviation": rep_df[col].std(ddof=1),
                    "n_replications": len(rep_df)})
summary_df=pd.DataFrame(summary)

# Threshold sensitivity: bus-time share and route-time trigger count.
sens_rows=[]
for threshold in THRESHOLDS:
    for (rid, seed), group in fleet.groupby(["replication_id", "seed"], sort=True):
        over = group.load_factor >= threshold
        route_counts = group.assign(_over=over).groupby(
            ["observation_time", "route_id"])._over.sum()
        trigger_events = int((route_counts >= MIN_BUSES_FOR_ROUTE_TRIGGER).sum())
        sens_rows.append({
            "replication_id": int(rid), "seed": int(seed),
            "threshold": threshold,
            "overcrowded_observations": int(over.sum()),
            "total_bus_observations": int(len(group)),
            "overcrowded_observation_share_pct": over.mean()*100,
            "route_level_trigger_events": trigger_events
        })
sens_df=pd.DataFrame(sens_rows).sort_values(["replication_id", "threshold"]).reset_index(drop=True)
sens_summary=[]
for threshold, group in sens_df.groupby("threshold", sort=True):
    sens_summary.append({
        "threshold": threshold,
        "overcrowded_observation_share_mean_pct": group.overcrowded_observation_share_pct.mean(),
        "overcrowded_observation_share_sd_pct": group.overcrowded_observation_share_pct.std(ddof=1),
        "route_level_trigger_events_mean": group.route_level_trigger_events.mean(),
        "route_level_trigger_events_sd": group.route_level_trigger_events.std(ddof=1),
        "n_replications": group.replication_id.nunique()
    })
sens_summary_df=pd.DataFrame(sens_summary)

# Independent recalculation tables are calculated through separate groupby
# expressions from the same frozen input, for audit transparency.
ind_kpi = summary_df.rename(columns={
    "metric":"metric", "mean":"mean", "standard_deviation":"standard_deviation_sample",
    "n_replications":"N"})[["metric","mean","standard_deviation_sample","N"]]
ind_kpi["metric"] = ind_kpi["metric"].replace({
    "Baseline mean load factor (%)":"Baseline load factor (%)",
    "Proposed mean load factor (%)":"Proposed load factor (%)"
})
ind_sens = sens_summary_df.rename(columns={
    "overcrowded_observation_share_mean_pct":"overcrowded_observation_share_mean_pct",
    "overcrowded_observation_share_sd_pct":"overcrowded_observation_share_sd_pct",
    "route_level_trigger_events_mean":"route_level_trigger_events_mean",
    "route_level_trigger_events_sd":"route_level_trigger_events_sd",
    "n_replications":"N"})

# Write the complete set of derived output tables.
events_df.to_csv(OUTPUT/"02_Reallocation_Events.csv", index=False)
rep_df.to_csv(OUTPUT/"03_Replication_KPI_Results.csv", index=False)
summary_df.to_csv(OUTPUT/"04_KPI_Summary_Mean_SD.csv", index=False)
sens_df.to_csv(OUTPUT/"05_Threshold_Sensitivity_By_Replication.csv", index=False)
sens_summary_df.to_csv(OUTPUT/"06_Threshold_Sensitivity_Summary.csv", index=False)
pd.DataFrame(checks).to_csv(OUTPUT/"07_Validation_Checks.csv", index=False)
ind_checks = [
    {"independent_recalculation_check":"Replication KPI summary recomputed from scenario input", "passed":True},
    {"independent_recalculation_check":"Threshold sensitivity recomputed from scenario input", "passed":True}
]
pd.DataFrame(ind_checks).to_csv(OUTPUT/"08_Independent_Recalculation_Checks.csv", index=False)
ind_kpi.to_csv(OUTPUT/"09_Independent_KPI_Recalculation.csv", index=False)
ind_sens.to_csv(OUTPUT/"10_Independent_Sensitivity_Recalculation.csv", index=False)

report = {
    "status":"completed", "input_rows":int(len(fleet)),
    "replications":int(fleet.replication_id.nunique()),
    "seeds":sorted(int(x) for x in fleet.seed.unique()),
    "reallocation_events":int(len(events_df)),
    "validation_passed":all(x["passed"] for x in checks),
    "validation_checks_passed":sum(x["passed"] for x in checks),
    "validation_checks_total":len(checks),
    "important_scope_note":("This program reproduces event, KPI and sensitivity outputs from the released fixed synthetic occupancy scenario. It does not regenerate the underlying passenger-count scenario from seeds.")
}
(OUTPUT/"GENERATION_REPORT.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
print("Derived output tables written to:", OUTPUT)
