# Chennai Transit Pulse – DBR Simulation Reproduction Package

## Purpose
This package reproduces the derived DBR event log, replication-level KPI tables, mean/standard-deviation summaries, and threshold-sensitivity tables used in the Comment 4 simulation evaluation.

## Important scope clarification
The released `input/synthetic_occupancy_scenario.csv` is the fixed synthetic occupancy scenario used in the evaluation. The Python program recalculates the DBR event log and all reported quantitative result tables from that input. **It does not regenerate the underlying passenger counts from random seeds.** The seed values identify the 30 synthetic replications in the scenario file; they are not used as a stochastic passenger-demand generator in this reproduction script. This limitation is stated explicitly to avoid overstating reproducibility.

The dataset is synthetic only. It is not real Chennai transit data and was not used as the operational data of the Chennai Transit Pulse prototype.

## Experimental design represented in the input
- 30 replications; seed identifiers 7001–7030
- 14 simulated buses; five synthetic routes (R1–R5)
- Capacity: 70 passengers per bus
- Horizon: 06:00–22:00; observations at 06:00, 08:00, 10:00, 12:00, 14:00, 16:00, 18:00 and 20:00
- Operational DBR threshold: 98%
- Sensitivity thresholds: 90%, 95%, 98%
- Route-level trigger: at least three buses on the same route at/above the threshold at an observation time
- Reallocation event status: admin-approved; automatic reassignment is false

## Stress-test disclosure
A controlled synthetic stress observation is present for three buses on route R1 at 18:00 in each replication. This is an experimental stress-test input, not a field observation.

## Requirements
- Python 3.9 or later
- pandas
- numpy

Install dependencies:

```bash
python -m pip install pandas numpy
```

## Run
From this directory:

```bash
python reproduce_simulation_results.py
```

The script writes derived CSV files and `GENERATION_REPORT.json` into the `output/` directory.

## KPI definitions
- Mean load factor (%) = mean of passenger_count / bus_capacity × 100 across bus-time observations within each replication.
- Overcrowded observation share (%) = bus-time observations with load factor at or above the selected threshold divided by all bus-time observations.
- Approved reallocations = count of route-time DBR trigger events logged as admin-approved per replication.
- Summary statistics = arithmetic mean and sample standard deviation (ddof=1) across 30 replication-level values.

## Interpretation and limitations
Baseline and proposed passenger-count inputs are identical. The event log records DBR triggers and admin approval but does not simulate passenger redistribution or post-reallocation occupancy changes. Therefore, this evaluation does not demonstrate a reduction in load factor or overcrowding. It does not provide waiting-time, reallocation-cost, complaint-resolution-time, or SOS-latency performance measurements. Results support a controlled synthetic simulation evaluation only, not real-world performance claims.
