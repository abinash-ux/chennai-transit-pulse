# License scope — Reviewer 3 Comments 4 & 5 package

Copyright attribution: Chennai Transit Pulse project
Copyright year: 2026

## CC BY 4.0 — data and documentation
`LICENSE-DATA-CC-BY-4.0.txt` applies to the synthetic datasets and documentation in this reproducibility package, including:
- all files in `comment4-results/`;
- `input/synthetic_occupancy_scenario.csv`;
- files in `scenarios/`;
- `simulation_config.json`;
- `SIMULATION_METHODOLOGY.md`;
- `README.md`, `README_and_Data_Dictionary.json`, and `AUDIT_REPORT.json`;
- other data/documentation files explicitly identified as CC BY 4.0.

Full legal code: https://creativecommons.org/licenses/by/4.0/legalcode

## MIT — reproduction code
`LICENSE-CODE-MIT.txt` applies only to `reproduce_simulation_results.py`.

## Exclusions
Neither license applies to the existing Chennai Transit Pulse application/source code, dependencies, third-party assets, or files outside this reproducibility package. Keep this package in a separate `simulation-reproducibility/` repository folder to avoid implying that the licenses cover the whole application repository.

Before public release, confirm that Chennai Transit Pulse project has the authority to license all included materials and that the synthetic data/script are original or otherwise cleared for release.
